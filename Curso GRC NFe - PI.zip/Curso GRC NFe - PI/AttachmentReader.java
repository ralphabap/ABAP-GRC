package sdn.sap.com.xi.nfe;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;

import com.sap.aii.mapping.api.AbstractTransformation;
import com.sap.aii.mapping.api.Attachment;
import com.sap.aii.mapping.api.DynamicConfiguration;
import com.sap.aii.mapping.api.DynamicConfigurationKey;
import com.sap.aii.mapping.api.InputAttachments;
import com.sap.aii.mapping.api.OutputAttachments;
import com.sap.aii.mapping.api.StreamTransformationException;
import com.sap.aii.mapping.api.TransformationInput;
import com.sap.aii.mapping.api.TransformationOutput;

public class AttachmentReader extends AbstractTransformation {

    InputAttachments inputAttachments = null;  
    OutputAttachments outputAttachments = null;  
    DynamicConfiguration conf = null;  
    
	@Override
	public void transform(TransformationInput tf_in, TransformationOutput tf_out) throws StreamTransformationException { 
		
        inputAttachments = tf_in.getInputAttachments();  
        outputAttachments = tf_out.getOutputAttachments();  
        conf = tf_in.getDynamicConfiguration();  
        
        this.execute(tf_in.getInputPayload().getInputStream(), tf_out.getOutputPayload().getOutputStream()); 

	}
	
	public void execute(InputStream in, OutputStream out)  
            throws StreamTransformationException {  
        // getTrace().addInfo("JAVA Mapping Called");  
        Attachment attachment;  
        String email = "";  
        String aid;  
        
        if (inputAttachments.areAttachmentsAvailable()) {  
        	
            Collection<String> attachments = inputAttachments.getAllContentIds(true);  
            Iterator<String> it = attachments.iterator();  
            
            // assuming only one attachment  
            while (it.hasNext()) {  
                aid = it.next();  
                attachment = inputAttachments.getAttachment(aid);  
                email = new String(attachment.getContent());  
                
                getTrace().addWarning("E-mail.: " + email);
                
                outputAttachments.removeAttachment(aid);  
            }  
            
            // Fill the dynamic configuration for the “to” field in the mail  
            // adapter  
            DynamicConfigurationKey key = DynamicConfigurationKey.create("http://sap.com/xi/XI/System/Mail", "THeaderTO");  
            
            conf.put(key, email);  
        } 
        
        // return the stream without doing anything  
        int c;  
        ByteArrayOutputStream baos = new ByteArrayOutputStream();  
        try {  
            while ((c = in.read()) != -1)  
                baos.write(c);  
            
            out.write(baos.toByteArray());  
            
        } catch (Exception e) {  
            throw new StreamTransformationException(e.getMessage());  
        }  
    } 

}
